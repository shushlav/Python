# public_8200bio_challenge

Name: <fillme>
Surname: <fillme>
email: <fillme>

Notes on the proposed solution:
<fillme>
